﻿' Author: Ryan Dunn
' Due Date: March 24th, 2020
' Prog Name: carLabFour
' Prog Desc: This form will accept user input of a cars make, model, year, price and if it is new or not
'            Then it will output the information into a list view.

Option Strict On

Public Class frmCarViewer

    Dim inputedCar As car            ' declared a car class object
    Dim isCarSelected As Boolean = False
    Dim isAddingToListView As Boolean = False
    Dim carList As New List(Of car)

    Dim years(2020) As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        For i As Integer = Date.Today.Year To car.minimumYear Step -1
            cbYear.Items.Add(i)
        Next

        cbMake.SelectedIndex = 0
        cbYear.SelectedIndex = 0
    End Sub

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        ' Validate the data in the form
        If IsValidInput() Then
            ' If car is selected
            If Not isCarSelected Then

                ' Create a new car and add to list
                inputedCar = New car(cbMake.Text, txtModel.Text, CInt(cbYear.SelectedItem.ToString), nudPrice.Value, cbNew.Checked)
                carList.Add(inputedCar)

                ' Else if car already exists, then just editing it
            ElseIf inputedCar.Id.Trim.Length > 0 Then

                ' Update the existing car based on input
                inputedCar.Make = cbMake.Text
                inputedCar.Model = txtModel.Text
                inputedCar.Year = CInt(cbYear.SelectedItem.ToString)
                inputedCar.Price = nudPrice.Value
                inputedCar.IsNew = cbNew.Checked
            End If

        End If

        SetDefaults()
    End Sub

    ''' <summary>
    ''' Resets the form
    ''' </summary>
    Private Sub SetDefaults()
        cbMake.SelectedIndex = 0
        txtModel.Clear()
        cbYear.SelectedIndex = 0
        nudPrice.Value = 0
        cbNew.Checked = False
        txtOutputBox.Clear()

        isCarSelected = False

        PopulateList()

    End Sub

    Private Function IsValidInput() As Boolean

        Dim returnValue As Boolean = True

        ' check if model entered
        If txtModel.Text.Trim.Length = 0 Then

            ' If not set the error message
            txtOutputBox.Text += "Please enter a car model." & vbCrLf

            ' And, set the return value to false
            returnValue = False

        End If

        Return returnValue

    End Function

    Private Sub lvCarDetailList_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvCarDetailList.SelectedIndexChanged

        If lvCarDetailList.SelectedIndices.Count = 1 Then
            inputedCar = carList(lvCarDetailList.SelectedIndices(0))
            isCarSelected = True

            cbMake.Text = inputedCar.Make
            txtModel.Text = inputedCar.Model
            cbYear.Text = inputedCar.Year.ToString()
            nudPrice.Value = inputedCar.Price
            cbNew.Checked = inputedCar.IsNew

        Else
            isCarSelected = False
        End If

    End Sub
    Private Sub lvCarDetailList_ItemCheck(sender As Object, e As ItemCheckEventArgs) Handles lvCarDetailList.ItemCheck

        ' If we're not currently adding new cars to the list
        If Not isAddingToListView Then

            ' Maintain the old checkbox value
            e.NewValue = e.CurrentValue

        End If

    End Sub

    ''' <summary>
    ''' Clears and re-populates the ListView control
    ''' </summary>
    Sub PopulateList()

        ' Clear the items from the listview control
        lvCarDetailList.Items.Clear()

        ' This For loop re-populates the list
        For index As Integer = 0 To carList.Count - 1

            ' instantiate new variable
            Dim carItem As New ListViewItem()

            ' assign the values to the checked control
            ' and the subitems
            carItem.SubItems.Add(carList(index).Id.ToString())
            carItem.SubItems.Add(carList(index).Make)
            carItem.SubItems.Add(carList(index).Model)
            carItem.SubItems.Add(carList(index).Year.ToString)
            carItem.SubItems.Add(carList(index).Price.ToString())
            carItem.Checked = carList(index).IsNew

            ' Done adding new cars to the ListView
            isAddingToListView = True

            ' add the new stuff to ListViewItem
            lvCarDetailList.Items.Add(carItem)

            ' Done adding new cars to the ListView
            isAddingToListView = False

        Next

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        SetDefaults()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class
