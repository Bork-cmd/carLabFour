﻿' Author: Ryan Dunn
' Due Date: March 24th, 2020
' File Name: car.vb
' File Desc: This form is for identifying different cars

Option Strict On
Public Class car

    Private Shared carCount As Integer = 0
    Private carIdentificationNumber As String = ""
    Private carMake As String = ""
    Private carModel As String = ""
    Private carYear As Integer = 0
    Private carPrice As Decimal = 0.0D
    Private carNewStatus As Boolean = True
    Private Shared theMinimumYear As Integer = 1920

    Friend Shared ReadOnly Property minimumYear() As Integer
        Get
            Return theMinimumYear
        End Get

    End Property

#Region "Constructors"

    ''' <summary>
    ''' default constructor for car class
    ''' </summary>
    Friend Sub New()

        carCount += 1
        carIdentificationNumber = carCount.ToString()

    End Sub

    ''' <summary>
    ''' Parametized constructor for car class; set couple instance variables based on values passed
    ''' </summary>
    ''' <param name="statusValue"></param>
    Friend Sub New(makeValue As String, modelValue As String, yearValue As Integer, priceValue As Decimal, statusValue As Boolean)

        Me.New()
        carMake = makeValue
        carModel = modelValue
        carYear = yearValue
        carPrice = priceValue
        carNewStatus = statusValue

    End Sub

#End Region

#Region "Properties"

    Friend Shared ReadOnly Property Count() As Integer
        Get
            Return carCount
        End Get
    End Property

    Friend ReadOnly Property Id() As String
        Get
            Return carIdentificationNumber
        End Get
    End Property

    Friend Property Make() As String
        Get
            Return carMake
        End Get
        Set(value As String)
            carMake = value
        End Set
    End Property

    Friend Property Model() As String
        Get
            Return carModel
        End Get
        Set(value As String)
            carModel = value
        End Set
    End Property

    Friend Property Year() As Integer
        Get
            Return carYear
        End Get
        Set(value As Integer)
            carYear = value
        End Set
    End Property

    Friend Property Price() As Decimal
        Get
            Return carPrice
        End Get
        Set(value As Decimal)
            carPrice = value
        End Set
    End Property

    Friend Property IsNew() As Boolean
        Get
            Return carNewStatus
        End Get
        Set(value As Boolean)
            carNewStatus = value
        End Set
    End Property

#End Region

#Region "Methods"

    ''' <summary>
    ''' Returns string describing car object
    ''' </summary>
    ''' <returns></returns>
    Friend Function getCarData() As String
        ' Method 1: Using an inline If statement
        Return IIf(carNewStatus, "New", "Used").ToString & " " & carYear.ToString() & " " & carMake & " " & carModel & " for " & carPrice.ToString("c")

    End Function

#End Region

End Class
