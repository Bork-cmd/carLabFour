﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmCarViewer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCarViewer))
        Me.lblMake = New System.Windows.Forms.Label()
        Me.lblModel = New System.Windows.Forms.Label()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.cbMake = New System.Windows.Forms.ComboBox()
        Me.cbYear = New System.Windows.Forms.ComboBox()
        Me.lvCarDetailList = New System.Windows.Forms.ListView()
        Me.chNew = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chId = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chMake = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chModel = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chPrice = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cbNew = New System.Windows.Forms.CheckBox()
        Me.txtModel = New System.Windows.Forms.TextBox()
        Me.txtOutputBox = New System.Windows.Forms.TextBox()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.nudPrice = New System.Windows.Forms.NumericUpDown()
        CType(Me.nudPrice, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblMake
        '
        Me.lblMake.AutoSize = True
        Me.lblMake.Location = New System.Drawing.Point(13, 13)
        Me.lblMake.Name = "lblMake"
        Me.lblMake.Size = New System.Drawing.Size(37, 13)
        Me.lblMake.TabIndex = 0
        Me.lblMake.Text = "Make:"
        '
        'lblModel
        '
        Me.lblModel.AutoSize = True
        Me.lblModel.Location = New System.Drawing.Point(13, 40)
        Me.lblModel.Name = "lblModel"
        Me.lblModel.Size = New System.Drawing.Size(39, 13)
        Me.lblModel.TabIndex = 1
        Me.lblModel.Text = "Model:"
        '
        'lblYear
        '
        Me.lblYear.AutoSize = True
        Me.lblYear.Location = New System.Drawing.Point(13, 67)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(32, 13)
        Me.lblYear.TabIndex = 2
        Me.lblYear.Text = "Year:"
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.Location = New System.Drawing.Point(13, 94)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(34, 13)
        Me.lblPrice.TabIndex = 3
        Me.lblPrice.Text = "Price:"
        '
        'cbMake
        '
        Me.cbMake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbMake.FormattingEnabled = True
        Me.cbMake.Items.AddRange(New Object() {"Volkswagen", "Volvo", "Hyundai", "Honda", "Tesla", "Mitsubishi", "Subaru"})
        Me.cbMake.Location = New System.Drawing.Point(51, 10)
        Me.cbMake.Name = "cbMake"
        Me.cbMake.Size = New System.Drawing.Size(121, 21)
        Me.cbMake.TabIndex = 1
        '
        'cbYear
        '
        Me.cbYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbYear.FormattingEnabled = True
        Me.cbYear.Location = New System.Drawing.Point(51, 64)
        Me.cbYear.Name = "cbYear"
        Me.cbYear.Size = New System.Drawing.Size(121, 21)
        Me.cbYear.TabIndex = 3
        '
        'lvCarDetailList
        '
        Me.lvCarDetailList.CheckBoxes = True
        Me.lvCarDetailList.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chNew, Me.chId, Me.chMake, Me.chModel, Me.chYear, Me.chPrice})
        Me.lvCarDetailList.FullRowSelect = True
        Me.lvCarDetailList.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvCarDetailList.HideSelection = False
        Me.lvCarDetailList.Location = New System.Drawing.Point(16, 144)
        Me.lvCarDetailList.MultiSelect = False
        Me.lvCarDetailList.Name = "lvCarDetailList"
        Me.lvCarDetailList.Size = New System.Drawing.Size(405, 227)
        Me.lvCarDetailList.TabIndex = 10
        Me.lvCarDetailList.TabStop = False
        Me.lvCarDetailList.UseCompatibleStateImageBehavior = False
        Me.lvCarDetailList.View = System.Windows.Forms.View.Details
        '
        'chNew
        '
        Me.chNew.Text = "New"
        '
        'chId
        '
        Me.chId.Text = "ID"
        '
        'chMake
        '
        Me.chMake.Text = "Make"
        Me.chMake.Width = 80
        '
        'chModel
        '
        Me.chModel.Text = "Model"
        Me.chModel.Width = 80
        '
        'chYear
        '
        Me.chYear.Text = "Year"
        '
        'chPrice
        '
        Me.chPrice.Text = "Price"
        '
        'cbNew
        '
        Me.cbNew.AutoSize = True
        Me.cbNew.Location = New System.Drawing.Point(13, 121)
        Me.cbNew.Name = "cbNew"
        Me.cbNew.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.cbNew.Size = New System.Drawing.Size(54, 17)
        Me.cbNew.TabIndex = 5
        Me.cbNew.Text = " :New"
        Me.cbNew.UseVisualStyleBackColor = True
        '
        'txtModel
        '
        Me.txtModel.Location = New System.Drawing.Point(51, 37)
        Me.txtModel.Name = "txtModel"
        Me.txtModel.Size = New System.Drawing.Size(121, 20)
        Me.txtModel.TabIndex = 2
        '
        'txtOutputBox
        '
        Me.txtOutputBox.Location = New System.Drawing.Point(16, 377)
        Me.txtOutputBox.Multiline = True
        Me.txtOutputBox.Name = "txtOutputBox"
        Me.txtOutputBox.ReadOnly = True
        Me.txtOutputBox.Size = New System.Drawing.Size(405, 103)
        Me.txtOutputBox.TabIndex = 14
        Me.txtOutputBox.TabStop = False
        '
        'btnEnter
        '
        Me.btnEnter.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnEnter.Location = New System.Drawing.Point(143, 487)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 23)
        Me.btnEnter.TabIndex = 6
        Me.btnEnter.Text = "Enter"
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(224, 487)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 7
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(305, 486)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'nudPrice
        '
        Me.nudPrice.Increment = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.nudPrice.Location = New System.Drawing.Point(51, 92)
        Me.nudPrice.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.nudPrice.Name = "nudPrice"
        Me.nudPrice.Size = New System.Drawing.Size(121, 20)
        Me.nudPrice.TabIndex = 4
        '
        'frmCarViewer
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnExit
        Me.ClientSize = New System.Drawing.Size(436, 514)
        Me.Controls.Add(Me.nudPrice)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.txtOutputBox)
        Me.Controls.Add(Me.txtModel)
        Me.Controls.Add(Me.cbNew)
        Me.Controls.Add(Me.lvCarDetailList)
        Me.Controls.Add(Me.cbYear)
        Me.Controls.Add(Me.cbMake)
        Me.Controls.Add(Me.lblPrice)
        Me.Controls.Add(Me.lblYear)
        Me.Controls.Add(Me.lblModel)
        Me.Controls.Add(Me.lblMake)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmCarViewer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Car Viewer"
        CType(Me.nudPrice, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblMake As Label
    Friend WithEvents lblModel As Label
    Friend WithEvents lblYear As Label
    Friend WithEvents lblPrice As Label
    Friend WithEvents cbMake As ComboBox
    Friend WithEvents cbYear As ComboBox
    Friend WithEvents lvCarDetailList As ListView
    Friend WithEvents cbNew As CheckBox
    Friend WithEvents chNew As ColumnHeader
    Friend WithEvents txtModel As TextBox
    Friend WithEvents chId As ColumnHeader
    Friend WithEvents chMake As ColumnHeader
    Friend WithEvents chModel As ColumnHeader
    Friend WithEvents chPrice As ColumnHeader
    Friend WithEvents chYear As ColumnHeader
    Friend WithEvents txtOutputBox As TextBox
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents nudPrice As NumericUpDown
End Class
